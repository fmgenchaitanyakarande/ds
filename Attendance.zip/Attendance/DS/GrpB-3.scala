object Factorial {
  def factorialIterative(n: Int): Int = {
    var result = 1
    for (i <- 1 to n) {
      result *= i
    }
    result
  }

  def main(args: Array[String]): Unit = {
    val num = 5
    val result = factorialIterative(num)
    println(s"Factorial of $num is $result")
  }
}
